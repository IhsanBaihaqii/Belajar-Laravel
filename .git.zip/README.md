## Remake PHP > Laravel

Membuat ulang Ripositories saya [UTS_WEB1_IhsanBaihaqi (PHP)](https://github.com/IhsanBaihaqii/UTS_WEB1_IhsanBaihaqi) menjadi bentuk [Laravel](https://laravel.com/)
